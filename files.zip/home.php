<?php
require 'config.php';

$user  = current_user();
$role  = $user['role'] ?? null;
$types = ['Ambulance', 'Van', 'SUV', 'Pickup', 'Other municipal vehicle'];
$roleLabels = ['admin' => 'Administrator', 'secretary' => 'Secretary', 'gso' => 'General Services Office', 'requester' => 'Requester'];

$error = '';
$v = ['purpose' => '', 'destination' => '', 'vehicle_type' => '', 'passenger_count' => 1, 'departure_at' => '', 'return_at' => '', 'is_emergency' => 0];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $v['purpose']         = trim($_POST['purpose'] ?? '');
    $v['destination']     = trim($_POST['destination'] ?? '');
    $v['vehicle_type']    = trim($_POST['vehicle_type'] ?? '');
    $v['passenger_count'] = (int)($_POST['passenger_count'] ?? 1);
    $v['departure_at']    = $_POST['departure_at'] ?? '';
    $v['return_at']       = $_POST['return_at'] ?? '';
    $v['is_emergency']    = isset($_POST['is_emergency']) ? 1 : 0;

    $depTs = strtotime($v['departure_at']);
    $retTs = strtotime($v['return_at']);

    if ($v['purpose'] === '' || $v['destination'] === '' || $v['vehicle_type'] === '' || !$depTs || !$retTs) {
        $error = 'Fill in every field before continuing.';
    } elseif (mb_strlen($v['purpose']) > 255 || mb_strlen($v['destination']) > 255) {
        $error = 'Purpose and destination must be 255 characters or fewer.';
    } elseif (!in_array($v['vehicle_type'], $types, true)) {
        $error = 'Choose a vehicle type from the list.';
    } elseif ($v['passenger_count'] < 1 || $v['passenger_count'] > 50) {
        $error = 'Passengers must be between 1 and 50.';
    } elseif ($retTs <= $depTs) {
        $error = 'The return time must be after the departure time.';
    } elseif ($depTs < time() - 300) {
        $error = 'The departure time cannot be in the past.';
    } else {
        // Keep the request in the session so it survives sign-in or account creation.
        $_SESSION['draft_request'] = [
            'purpose'         => $v['purpose'],
            'destination'     => $v['destination'],
            'vehicle_type'    => $v['vehicle_type'],
            'passenger_count' => $v['passenger_count'],
            'departure_at'    => date('Y-m-d\TH:i', $depTs),
            'return_at'       => date('Y-m-d\TH:i', $retTs),
            'is_emergency'    => $v['is_emergency'],
        ];
        if (logged_in()) {
            go($role === 'requester' ? 'reservations.php?new=1' : 'dashboard.php');
        }
        go(($_POST['next'] ?? '') === 'login' ? 'index.php?from=request' : 'register.php?from=request');
    }
}
$minDt = date('Y-m-d\TH:i');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Request a municipal vehicle | LGU Inabanga</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,500..800&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --bay:#0F3A5F; --bay-deep:#0A2740; --sign:#FFC629; --sign-dark:#E5AC10;
  --ink:#16202B; --muted:#55626F; --line:#C9D3DC; --page:#EEF2F5; --paper:#FFFFFF; --danger:#A32020;
  --head:'Archivo','Arial Narrow','Helvetica Neue',Arial,sans-serif;
  --body:'IBM Plex Sans','Segoe UI',Roboto,Arial,sans-serif;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--page);color:var(--ink);font:400 16px/1.55 var(--body)}
a{color:inherit}
:focus-visible{outline:3px solid var(--sign);outline-offset:2px}
.wrap{width:min(1120px,100% - 40px);margin-inline:auto}

/* top bar + hero share the bay-blue field */
.hero{background:var(--bay);color:#fff;padding-bottom:72px}
.bar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:20px 0}
.brand{display:flex;align-items:center;gap:12px;text-decoration:none}
.brand-mark{width:38px;height:38px;border-radius:8px;background:var(--sign);color:var(--bay-deep);display:grid;place-items:center;font:700 20px/1 var(--head)}
.brand b{display:block;font:700 18px/1.1 var(--head);font-stretch:80%;letter-spacing:.02em}
.brand span{display:block;font-size:13px;color:#B9CADA}
.nav{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.nav a{text-decoration:none;font-weight:500;padding:9px 14px;border-radius:6px}
.nav a.link:hover{background:rgba(255,255,255,.1)}
.nav a.pill{background:var(--sign);color:var(--bay-deep);font-weight:600}
.nav a.pill:hover{background:var(--sign-dark)}

.hero-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,520px);gap:56px;align-items:start;padding-top:36px}
h1{font:700 clamp(40px,6vw,68px)/.98 var(--head);font-stretch:75%;letter-spacing:-.01em;margin:8px 0 20px}
.lede{font-size:18px;color:#D5E1EC;max-width:46ch;margin:0 0 28px}
.facts{list-style:none;margin:0;padding:0;display:grid;gap:14px;max-width:46ch}
.facts li{padding-left:18px;border-left:3px solid var(--sign);color:#E4ECF3}
.facts b{color:#fff;font-weight:600}

/* the memorable element: a trip ticket */
.ticket{position:relative;background:var(--paper);color:var(--ink);border-radius:6px;box-shadow:0 18px 40px rgba(5,20,35,.35)}
.ticket-head{position:relative;display:flex;justify-content:space-between;align-items:baseline;gap:12px;padding:22px 26px 18px;border-bottom:2px dashed var(--line)}
.ticket-head::before,.ticket-head::after{content:"";position:absolute;bottom:-11px;width:20px;height:20px;border-radius:50%;background:var(--bay)}
.ticket-head::before{left:-10px}.ticket-head::after{right:-10px}
.ticket-head h2{margin:0;font:700 26px/1 var(--head);font-stretch:80%}
.ticket-head small{color:var(--muted);font-size:13px;text-align:right}
.ticket-body{padding:24px 26px 26px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.span{grid-column:1/-1}
label{display:block;font-weight:500;font-size:14px}
input,select{width:100%;margin-top:6px;padding:11px 12px;border:1.5px solid var(--line);border-radius:6px;background:#fff;color:var(--ink);font:inherit}
input:hover,select:hover{border-color:#9FB0BF}
input:focus,select:focus{outline:none;border-color:var(--bay);box-shadow:0 0 0 3px rgba(15,58,95,.2)}
.check{display:flex;gap:10px;align-items:flex-start;font-weight:400}
.check input{width:20px;height:20px;margin:2px 0 0;accent-color:var(--bay)}
.check small{display:block;color:var(--muted)}
.alert{margin:0 0 16px;padding:12px 14px;border-radius:6px;background:#FCEBEB;border:1px solid #E6B8B8;color:var(--danger);font-weight:500}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}
.btn{appearance:none;border:2px solid transparent;border-radius:6px;padding:12px 18px;font:600 15px/1.2 var(--body);cursor:pointer;text-decoration:none;display:inline-block;text-align:center}
.btn.primary{background:var(--sign);color:var(--bay-deep);border-color:var(--sign)}
.btn.primary:hover{background:var(--sign-dark);border-color:var(--sign-dark)}
.btn.ghost{background:transparent;color:var(--bay);border-color:var(--bay)}
.btn.ghost:hover{background:rgba(15,58,95,.07)}
.fine{margin:14px 0 0;font-size:13px;color:var(--muted)}
.notice p{margin:0 0 14px}

/* sections under the hero */
section.block{padding:64px 0 0}
h2.title{font:700 clamp(28px,3.6vw,40px)/1.05 var(--head);font-stretch:80%;margin:0 0 8px}
.sub{color:var(--muted);margin:0 0 28px;max-width:60ch}
.steps{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(5,1fr);gap:0;counter-reset:s;border-top:3px solid var(--bay)}
.steps li{counter-increment:s;padding:18px 16px 0 0;position:relative}
.steps li::before{content:counter(s);display:grid;place-items:center;width:30px;height:30px;margin-top:-34px;margin-bottom:12px;border-radius:50%;background:var(--bay);color:#fff;font:700 15px/1 var(--head)}
.steps b{display:block;font-weight:600}
.steps span{color:var(--muted);font-size:14px}
.fleet{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:0;border:1.5px solid var(--line);background:var(--paper);border-radius:6px}
.fleet div{padding:18px 20px;border-right:1.5px solid var(--line)}
.fleet div:last-child{border-right:0}
.fleet b{display:block;font:700 20px/1.1 var(--head);font-stretch:85%;margin-bottom:4px}
.fleet span{color:var(--muted);font-size:14px}
footer{margin-top:72px;padding:26px 0 40px;border-top:1.5px solid var(--line);color:var(--muted);font-size:14px}
footer .wrap{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap}

@media (max-width:900px){
  .hero-grid{grid-template-columns:1fr;gap:36px}
  .steps{grid-template-columns:1fr;border-top:0;border-left:3px solid var(--bay);padding-left:0}
  .steps li{padding:0 0 22px 28px}
  .steps li::before{position:absolute;left:-16px;top:0;margin:0}
  .fleet div{border-right:0;border-bottom:1.5px solid var(--line)}
  .fleet div:last-child{border-bottom:0}
}
@media (max-width:520px){
  .grid{grid-template-columns:1fr}
  .ticket-head{flex-direction:column;align-items:flex-start}
  .ticket-head small{text-align:left}
  .ticket-head,.ticket-body{padding-inline:18px}
  .actions .btn{width:100%}
}
</style>
</head>
<body>

<header class="hero">
  <div class="wrap">
    <div class="bar">
      <a class="brand" href="home.php" aria-label="Inabanga Vehicle Services home">
        <span class="brand-mark" aria-hidden="true">I</span>
        <span><b>Inabanga vehicle services</b><span>Municipal General Services Office</span></span>
      </a>
      <nav class="nav" aria-label="Account">
        <?php if (logged_in()): ?>
          <a class="link" href="dashboard.php">Dashboard</a>
          <a class="pill" href="logout.php">Sign out</a>
        <?php else: ?>
          <a class="link" href="index.php">Sign in</a>
          <a class="pill" href="register.php">Create account</a>
        <?php endif; ?>
      </nav>
    </div>

    <div class="hero-grid">
      <div>
        <h1>Book a municipal vehicle</h1>
        <p class="lede">Tell us where you're going and when. Sign in or create an account to send the request, then follow it until the vehicle is back.</p>
        <ul class="facts">
          <li><b>Need an ambulance now?</b> Tick the urgent box. Urgent requests are listed first for review.</li>
          <li><b>Your request is tracked.</b> You'll see each decision, the assigned vehicle and driver, and the return.</li>
          <li><b>No paper slip.</b> The reference number is issued when your request is sent.</li>
        </ul>
      </div>

      <div class="ticket" id="request">
        <div class="ticket-head">
          <h2>Trip request</h2>
          <small>Reference number is issued<br>after you send it</small>
        </div>
        <div class="ticket-body">
        <?php if ($role && $role !== 'requester'): ?>
          <div class="notice">
            <p>You're signed in as <b><?=h($roleLabels[$role] ?? $role)?></b>. Only requester accounts send trip requests.</p>
            <a class="btn primary" href="dashboard.php">Go to dashboard</a>
          </div>
        <?php else: ?>
          <?php if ($error): ?><div class="alert" role="alert"><?=h($error)?></div><?php endif; ?>
          <form method="post" action="home.php#request" novalidate>
            <?=csrf_field()?>
            <div class="grid">
              <label class="span">Purpose of trip
                <input name="purpose" value="<?=h($v['purpose'])?>" maxlength="255" required placeholder="Official meeting, medical transport">
              </label>
              <label class="span">Destination
                <input name="destination" value="<?=h($v['destination'])?>" maxlength="255" required placeholder="Municipality or address">
              </label>
              <label>Vehicle type
                <select name="vehicle_type" required>
                  <option value="">Select a type</option>
                  <?php foreach ($types as $t): ?><option<?=$v['vehicle_type'] === $t ? ' selected' : ''?>><?=h($t)?></option><?php endforeach; ?>
                </select>
              </label>
              <label>Passengers
                <input type="number" name="passenger_count" min="1" max="50" value="<?=(int)$v['passenger_count']?>" required>
              </label>
              <label>Departure
                <input type="datetime-local" name="departure_at" min="<?=h($minDt)?>" value="<?=h($v['departure_at'])?>" required>
              </label>
              <label>Expected return
                <input type="datetime-local" name="return_at" min="<?=h($minDt)?>" value="<?=h($v['return_at'])?>" required>
              </label>
              <label class="span check">
                <input type="checkbox" name="is_emergency" value="1"<?=$v['is_emergency'] ? ' checked' : ''?>>
                <span>This is urgent or an emergency<small>Urgent requests are shown first to reviewers.</small></span>
              </label>
            </div>
            <div class="actions">
              <?php if ($role === 'requester'): ?>
                <button class="btn primary" type="submit">Continue to send request</button>
              <?php else: ?>
                <button class="btn primary" type="submit" name="next" value="register">Create account and send</button>
                <button class="btn ghost" type="submit" name="next" value="login">Sign in and send</button>
              <?php endif; ?>
            </div>
            <p class="fine">Your trip details are kept for this visit, so you won't have to type them again after signing in.</p>
          </form>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</header>

<main class="wrap">
  <section class="block" aria-labelledby="flow">
    <h2 class="title" id="flow">What happens after you send it</h2>
    <p class="sub">Every request goes through the same review before a vehicle is released.</p>
    <ol class="steps">
      <li><b>Administrative review</b><span>The administrator checks your request and forwards it.</span></li>
      <li><b>Secretary decision</b><span>The secretary approves or declines it.</span></li>
      <li><b>Vehicle and driver</b><span>The GSO assigns a vehicle and driver for your dates.</span></li>
      <li><b>Dispatch</b><span>Odometer and fuel are recorded when the vehicle leaves.</span></li>
      <li><b>Return</b><span>Mileage, fuel and condition are recorded to close the trip.</span></li>
    </ol>
  </section>

  <section class="block" aria-labelledby="fleet">
    <h2 class="title" id="fleet">Vehicles you can request</h2>
    <p class="sub">Final availability depends on the dates you choose and what is already scheduled.</p>
    <div class="fleet">
      <div><b>Ambulance</b><span>Emergency and medical transport, given priority.</span></div>
      <div><b>Van</b><span>Group travel for official events and programs.</span></div>
      <div><b>SUV</b><span>Official trips for smaller groups.</span></div>
      <div><b>Pickup</b><span>Hauling and field work.</span></div>
    </div>
  </section>
</main>

<footer>
  <div class="wrap">
    <span>© <?=date('Y')?> LGU Inabanga, Bohol</span>
    <span>Questions? Visit the Municipal General Services Office.</span>
  </div>
</footer>

</body>
</html>
